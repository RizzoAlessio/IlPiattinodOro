package test;
import org.junit.Test;
import main.IlPiattinodOro;
import org.junit.BeforeClass;
import static org.junit.Assert.*;

public class TestGioco {

    static IlPiattinodOro sistema;

    @BeforeClass
    public static void initTest() {
        sistema = IlPiattinodOro.getInstance();
    }

    @Test
    public void testInserisciNuovoGioco() {
        sistema.InserisciGioco("04", "Pac Man", "Cabinato", 1);
        assertNotNull(sistema.getGiocoCorrente());
        
    }

    @Test
    public void testInserisciPrezzo() {
        sistema.InserisciGioco("04", "Pac Man", "Cabinato", 1);
        assertNotNull(sistema.getGiocoCorrente());
        sistema.DefinisciCosto(12);
        assertNotNull(sistema.getGiocoCorrente());
    }

    @Test
    public void testConferma() {

        sistema.InserisciGioco("04", "Pac Man", "Cabinato", 1);
        assertNotNull(sistema.getGiocoCorrente());
        sistema.DefinisciCosto(12);
        assertNotNull(sistema.getGiocoCorrente());
        sistema.FineInserimento();
        assertEquals(4, sistema.getElencoGiochi().size());

    }

}
